Crypto++ Library 5.3.0
FIPS 140-2 Download Package ReadMe 8/14/2007
This package is divided into these subdirectories:

API_Reference - API Reference Manual. Open index.html for the front page.
Debug32 - Win32 Debug build of the Crypto++ DLL. This build is not FIPS validated.
Debug64 - Win64 Debug build of the Crypto++ DLL. This build is not FIPS validated.
DllTest - Source code and project file for the DllTest sample application.
FIPS_Documentation - Security Policy, Crypto Officer's Guide and User's Guide.
Include - Crypto++ header (.h) files for the DLL.
Release32 - Win32 Release build of the Crypto++ DLL. This is a FIPS validated module.
Release64 - Win64 Release build of the Crypto++ DLL. This is a FIPS validated module.
Source - Full Crypto++ source code.

This release is licensed under the standard Crypto++ license, which is
included as License.txt.

Please read the Readme.txt file in the Source directory, which contains
additional important information that is not specific to FIPS 140-2.
