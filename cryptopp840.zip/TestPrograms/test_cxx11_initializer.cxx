#include <vector>
int main(int argc, char* argv[])
{
    std::vector<int> v{0,1,2,3,4};
    return 0;
}
